﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Eisk.MVCApp")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("WWW.ASHRAFUL.NET")]
[assembly: AssemblyProduct("Eisk.MVCApp")]
[assembly: AssemblyCopyright("Copyright ©  2012")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("a24b690c-e784-4e93-b75d-ec9b9409fec7")]
[assembly: AssemblyVersion("5.6.100.0")]
[assembly: AssemblyFileVersion("5.6.100.0")]
